export class Product {}
